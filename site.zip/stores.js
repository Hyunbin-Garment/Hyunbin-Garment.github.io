/** Store information is supplied by the brand in stores.json. No sample stores are published. */
const text = value => typeof value === 'string' ? value.trim() : '';
const normalizedText = value => text(value).normalize('NFKC').toLocaleLowerCase('zh-CN');
const finiteCoordinate = (value, min, max) => typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;

export function hasCoordinates(store) {
  return finiteCoordinate(store?.lat, -90, 90) && finiteCoordinate(store?.lng, -180, 180);
}

export function normalizeStores(value) {
  if (!Array.isArray(value)) throw new TypeError('门店数据格式不正确');
  const seen = new Set();
  return value.flatMap(item => {
    if (!item || typeof item !== 'object') return [];
    const id = text(item.id);
    const name = text(item.name);
    const city = text(item.city);
    const address = text(item.address);
    if (!id || !name || !city || !address || seen.has(id)) return [];
    seen.add(id);
    return [{
      id, name, city, address, province: text(item.province),
      district: text(item.district), phone: text(item.phone), hours: text(item.hours),
      availability: text(item.availability), wechat: text(item.wechat), mapUrl: safeMapUrl(item.mapUrl),
      lat: hasCoordinates(item) ? item.lat : null,
      lng: hasCoordinates(item) ? item.lng : null,
      tags: Array.isArray(item.tags) ? [...new Set(item.tags.map(text).filter(Boolean))].slice(0, 8) : [],
    }];
  });
}

export function distanceKm(a, b) {
  if (!hasCoordinates(a) || !hasCoordinates(b)) return Infinity;
  const rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad;
  const dLng = (b.lng - a.lng) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
  return 6371.0088 * 2 * Math.asin(Math.sqrt(Math.max(0, Math.min(1, h))));
}

export function filterStores(stores, query = '', city = '', position = null) {
  const terms = normalizedText(query).split(/\s+/u).filter(Boolean);
  const chosenCity = normalizedText(city);
  const filtered = stores.filter(store => {
    if (chosenCity && normalizedText(store.city) !== chosenCity) return false;
    const searchable = normalizedText([store.name, store.province, store.city, store.district, store.address, ...(store.tags || [])].join(' '));
    return terms.every(term => searchable.includes(term));
  });
  if (hasCoordinates(position)) filtered.sort((a, b) => distanceKm(position, a) - distanceKm(position, b));
  return filtered;
}

export function safeMapUrl(value) {
  try {
    const url = new URL(text(value));
    if (url.protocol !== 'https:' || url.username || url.password) return '';
    return url.href;
  } catch { return ''; }
}

export function storeMapUrl(store) {
  const supplied = safeMapUrl(store.mapUrl);
  if (supplied) return supplied;
  if (hasCoordinates(store)) {
    const url = new URL('https://uri.amap.com/marker');
    url.search = new URLSearchParams({ position: `${store.lng},${store.lat}`, name: store.name, coordinate: 'gaode', src: 'hyunbin', callnative: '0' }).toString();
    return url.href;
  }
  const url = new URL('https://uri.amap.com/search');
  url.search = new URLSearchParams({ keyword: `${store.name} ${store.address}`, city: store.city, view: 'map', src: 'hyunbin', callnative: '0' }).toString();
  return url.href;
}

export function telephoneUrl(value) {
  const phone = text(value).replace(/[\s()（）-]/g, '');
  return /^(?:\+86)?[0-9]{7,12}$/.test(phone) ? `tel:${phone}` : '';
}

function element(tag, className, content) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (content !== undefined) node.textContent = content;
  return node;
}

function action(label, className, onClick) {
  const button = element('button', className, label);
  button.type = 'button';
  button.addEventListener('click', onClick);
  return button;
}

function mapLink(store) {
  const link = element('a', 'store-action store-map-link', '地图导航 ↗');
  link.href = storeMapUrl(store);
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  link.setAttribute('aria-label', `${store.name}：打开地图（新窗口）`);
  return link;
}

function emptyState(title, copy) {
  const section = element('div', 'store-empty');
  section.append(element('h3', '', title), element('p', '', copy));
  return section;
}

/** Call once after the document has loaded. Returns a cleanup function. */
export async function initStores({ dataUrl = new URL('./stores.json', import.meta.url), fetcher = globalThis.fetch } = {}) {
  const search = document.querySelector('#store-search');
  const city = document.querySelector('#store-city');
  const results = document.querySelector('#store-results');
  const count = document.querySelector('#store-count');
  const status = document.querySelector('#store-status');
  const locate = document.querySelector('#locate-stores');
  const dialog = document.querySelector('#store-detail');
  const finder = document.querySelector('.store-finder');
  if (!search || !city || !results || !count || !status || !locate || !dialog) return () => {};
  if (results.dataset.storesInitialized === 'true') return () => {};
  results.dataset.storesInitialized = 'true';
  status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite');
  results.setAttribute('aria-busy', 'true');
  const controller = new AbortController();
  let stores = [];
  let position = null;
  let disposed = false;
  let locating = false;
  let lastTrigger = null;
  const announce = message => { status.textContent = message; };

  const restoreFocus = () => {
    if (lastTrigger?.isConnected) lastTrigger.focus({ preventScroll: true });
  };
  const closeDetail = () => {
    if (typeof dialog.close === 'function') dialog.close();
    else {
      dialog.removeAttribute('open');
      restoreFocus();
    }
  };

  async function copyAddress(store, feedback) {
    const fullAddress = store.address;
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(fullAddress);
      feedback.textContent = '地址已复制。';
    } catch {
      feedback.textContent = '暂时无法自动复制，请选中上方地址复制。';
    }
  }

  function openDetail(store, trigger) {
    lastTrigger = trigger;
    const body = element('div', 'store-detail-body');
    const heading = element('h2', 'store-detail-title', store.name);
    heading.id = 'store-detail-title';
    dialog.setAttribute('aria-labelledby', heading.id);
    body.append(action('关闭 ×', 'store-detail-close', closeDetail));
    body.append(element('p', 'store-eyebrow', `${store.city}${store.district ? ` · ${store.district}` : ''}`), heading);
    const address = element('p', 'store-detail-address', store.address);
    body.append(address);
    const facts = element('dl', 'store-facts');
    [['营业时间', store.hours || '请向门店确认'], ['联系电话', store.phone], ['微信', store.wechat], ['到店提示', store.availability]].forEach(([label, value]) => {
      if (!value) return;
      const group = element('div', 'store-fact');
      group.append(element('dt', '', label), element('dd', '', value));
      facts.append(group);
    });
    body.append(facts);
    const links = element('div', 'store-actions');
    links.append(mapLink(store));
    const phone = telephoneUrl(store.phone);
    if (phone) {
      const link = element('a', 'store-action', '致电门店 ↗');
      link.href = phone;
      links.append(link);
    }
    const feedback = element('p', 'store-copy-status');
    feedback.setAttribute('role', 'status');
    links.append(action('复制地址', 'store-action', () => copyAddress(store, feedback)));
    body.append(links, feedback);
    dialog.replaceChildren(body);
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  }

  function render() {
    const visible = filterStores(stores, search.value, city.value, position);
    count.textContent = stores.length ? `${visible.length} 家门店` : '门店目录';
    finder?.classList.toggle('is-pending', !stores.length);
    if (!stores.length) {
      results.replaceChildren(emptyState('门店信息准备中', '门店地址正在整理，稍后更新。'));
      return 0;
    }
    if (!visible.length) {
      const empty = emptyState('暂未找到匹配门店', '试试其他城市、商圈或门店名称。');
      empty.append(action('清除筛选', 'store-action', () => {
        search.value = '';
        city.value = '';
        render();
        search.focus();
        announce('已清除筛选。');
      }));
      results.replaceChildren(empty);
      return 0;
    }
    const fragment = document.createDocumentFragment();
    visible.forEach((store, index) => {
      const card = element('article', 'store-card');
      const upper = element('div', 'store-card-heading');
      upper.append(element('span', 'store-card-index', String(index + 1).padStart(2, '0')));
      const location = element('span', 'store-meta', [store.city, store.district].filter(Boolean).join(' · '));
      upper.append(location);
      if (position && hasCoordinates(store)) {
        const distance = distanceKm(position, store);
        upper.append(element('span', 'store-distance', `距您约 ${distance < 1 ? '< 1' : Math.round(distance)} km`));
      }
      card.append(upper, element('h3', '', store.name), element('p', 'store-address', store.address));
      if (store.hours) card.append(element('p', 'store-meta store-hours', store.hours));
      if (store.tags.length) {
        const tags = element('div', 'store-tags');
        store.tags.forEach(tag => tags.append(element('span', 'store-tag', tag)));
        card.append(tags);
      }
      const actions = element('div', 'store-actions');
      const details = action('门店详情 →', 'store-action', event => openDetail(store, event.currentTarget));
      details.setAttribute('aria-label', `查看${store.name}详情`);
      actions.append(details, mapLink(store));
      card.append(actions);
      fragment.append(card);
    });
    results.replaceChildren(fragment);
    return visible.length;
  }

  const onFilter = () => {
    const matches = render();
    announce(stores.length ? `找到 ${matches} 家门店。` : '门店地址整理中，暂未开放搜索。');
  };
  const onLocate = () => {
    if (!stores.length) { announce('门店地址整理中，暂未开放附近门店查询。'); return; }
    if (!stores.some(hasCoordinates)) { announce('门店位置坐标正在补充，请先按城市查找。'); return; }
    if (locating) return;
    if (!navigator.geolocation) { announce('当前浏览器不支持定位，请按城市查找门店。'); return; }
    locating = true;
    locate.disabled = true;
    locate.setAttribute('aria-busy', 'true');
    announce('正在获取您的位置…');
    const finish = () => { locating = false; locate.disabled = false; locate.removeAttribute('aria-busy'); };
    navigator.geolocation.getCurrentPosition(location => {
      if (disposed) return;
      finish();
      position = { lat: location.coords.latitude, lng: location.coords.longitude };
      city.value = '';
      search.value = '';
      render();
      announce('已按附近距离估算排序。定位可能有偏移，实际路程以地图为准；缺少坐标的门店显示在最后。');
    }, error => {
      if (disposed) return;
      finish();
      const message = error.code === 1 ? '定位权限未开启。您仍可按城市、商圈或门店名称查找。' : error.code === 3 ? '定位超时，请重试或按城市查找。' : '暂时无法获取位置，请重试或按城市查找。';
      announce(message);
    }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
  };
  search.addEventListener('input', onFilter);
  city.addEventListener('change', onFilter);
  locate.addEventListener('click', onLocate);
  dialog.addEventListener('close', restoreFocus);

  try {
    const response = await fetcher(dataUrl, { signal: controller.signal, cache: 'no-cache' });
    if (!response.ok) throw new Error('Store data could not be loaded');
    stores = normalizeStores(await response.json());
    if (disposed) return () => {};
    const all = element('option', '', '全部城市');
    all.value = '';
    city.replaceChildren(all);
    [...new Set(stores.map(store => store.city))].sort((a, b) => a.localeCompare(b, 'zh-CN')).forEach(name => {
      const option = element('option', '', name);
      option.value = name;
      city.append(option);
    });
    search.disabled = !stores.length;
    city.disabled = !stores.length;
    locate.disabled = !stores.length;
    locate.setAttribute('aria-describedby', 'store-status');
    render();
    announce(stores.length ? `共 ${stores.length} 家门店，可按城市或关键词查找。` : '门店信息正在更新，敬请期待。');
  } catch (error) {
    if (error.name !== 'AbortError') {
      count.textContent = '暂时无法加载';
      results.replaceChildren(emptyState('门店信息暂时无法加载', '请刷新页面重试。'));
      announce('门店信息加载失败，请刷新页面后重试。');
      search.disabled = true;
      city.disabled = true;
      locate.disabled = true;
    }
  } finally {
    results.setAttribute('aria-busy', 'false');
  }
  return () => {
    disposed = true;
    controller.abort();
    search.removeEventListener('input', onFilter);
    city.removeEventListener('change', onFilter);
    locate.removeEventListener('click', onLocate);
    dialog.removeEventListener('close', restoreFocus);
    delete results.dataset.storesInitialized;
  };
}
