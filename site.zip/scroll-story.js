const FRAME_COUNT = 60;
const MEDIA_VERSION = '98e98c0ea485';
const CHAPTERS = [
  { folder: '', poster: 'cotton.webp', fit: 'cotton', frames: 1 },
  { folder: 'yarn', poster: 'yarn/001.webp', fit: 'cover', frames: FRAME_COUNT },
  { folder: 'loom', poster: 'loom/001.webp', fit: 'cover', frames: FRAME_COUNT },
  { folder: 'cut', poster: 'cut/001.webp', fit: 'cover', frames: FRAME_COUNT },
  { folder: '', poster: 'garment-concept.webp', fit: 'garment', frames: 1 },
];
const BASE = new URL('./assets/journey/', import.meta.url);
const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const smooth = value => { const t = clamp(value); return t * t * (3 - 2 * t); };

/** One progress value controls imagery, chapter copy, and navigation in both directions. */
export function storyState(progress) {
  const position = clamp(progress) * CHAPTERS.length;
  const chapter = Math.min(CHAPTERS.length - 1, Math.floor(position));
  const local = chapter === CHAPTERS.length - 1 && position === CHAPTERS.length ? 1 : position - chapter;
  const transitionStart = chapter === 3 ? .72 : .88;
  const blend = chapter < CHAPTERS.length - 1 ? smooth((local - transitionStart) / (1 - transitionStart)) : 0;
  return {
    chapter, local, blend,
    frame: 1 + Math.round(clamp(local / .88) * (CHAPTERS[chapter].frames - 1)),
    active: blend > .5 ? chapter + 1 : chapter,
  };
}

export function progressFromBounds(top, sectionHeight, stageHeight) {
  return clamp(-top / Math.max(1, sectionHeight - stageHeight));
}

/** Source chest point stays continuous while a fabric close-up resolves into a complete garment. */
export function endingPose({ width, height, imageWidth, imageHeight, local }) {
  const shortLandscape = height <= 480 && width > height;
  const compact = !shortLandscape && (width <= 760 || width / height < 1);
  const rect = shortLandscape
    ? { x: width * .52, y: height * .17, w: width * .43, h: height * .56 }
    : compact
      ? { x: width * .08, y: height * .22, w: width * .84, h: height * .58 }
      : { x: width * .49, y: height * .11, w: width * .48, h: height * .79 };
  const finalScale = Math.min(rect.w / imageWidth, rect.h / imageHeight);
  const finalX = rect.x + (rect.w - imageWidth * finalScale) / 2;
  const finalY = rect.y + (rect.h - imageHeight * finalScale) / 2;
  const sourceFocus = { x: imageWidth * .56, y: imageHeight * .5 };
  // The opening samples only the central fabric panel, not transparent sleeve edges.
  const initialScale = Math.max(width / (imageWidth * .32), height / (imageHeight * .28));
  const t = smooth(local / .65);
  const scale = initialScale * Math.pow(finalScale / initialScale, t);
  const focus = {
    x: width * .5 + (finalX + sourceFocus.x * finalScale - width * .5) * t,
    y: height * .5 + (finalY + sourceFocus.y * finalScale - height * .5) * t,
  };
  return {
    x: focus.x - sourceFocus.x * scale,
    y: focus.y - sourceFocus.y * scale,
    w: imageWidth * scale,
    h: imageHeight * scale,
    scale, focus, sourceFocus, rect, compact, shortLandscape,
    titleOpacity: smooth((local - .3) / .25),
    ctaOpacity: smooth((local - .73) / .15),
  };
}

export function initScrollStory() {
  const root = document.querySelector('#journey');
  const stage = root?.querySelector('.journey-stage');
  const canvas = document.querySelector('#journey-canvas');
  const chapters = [...(root?.querySelectorAll('.journey-chapter') || [])];
  const buttons = [...(root?.querySelectorAll('[data-step]') || [])];
  if (!root || !stage || !canvas || chapters.length !== CHAPTERS.length) return () => {};
  let context;
  try { context = canvas.getContext('2d', { alpha: false }); } catch { return () => {}; }
  if (!context) return () => {};
  // Composite a complete opaque scene once, so transparent garment pixels never
  // expose the previous scene through a second alpha pass.
  let transitionLayer;
  let transitionContext;
  try {
    transitionLayer = document.createElement('canvas');
    transitionContext = transitionLayer.getContext('2d', { alpha: false });
  } catch { return () => {}; }
  if (!transitionContext) return () => {};

  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const originalButtonDisabled = buttons.map(button => button.disabled);
  const chapterInteraction = chapters.map(chapter => ({
    inert: Boolean(chapter.inert),
    focusables: [...chapter.querySelectorAll('a[href], button, input, select, textarea, [tabindex]')]
      .map(node => ({
        node, tabindex: node.getAttribute('tabindex'),
        ariaHidden: node.getAttribute('aria-hidden'), pointerEvents: node.style.pointerEvents,
      })),
  }));
  const cache = new Map();
  const pending = new Set();
  const failed = new Set();
  let queue = new Map();
  let enabled = false;
  let disposed = false;
  let readinessFailed = false;
  let raf = 0;
  let width = 0;
  let height = 0;
  let current = storyState(0);
  const keyFor = (chapter, frame = 1) => `${chapter}:${frame}`;
  const isPoster = key => key.endsWith(':1');
  const urlFor = (chapter, frame) => {
    const url = new URL(CHAPTERS[chapter].frames === 1
      ? CHAPTERS[chapter].poster
      : `${CHAPTERS[chapter].folder}/${String(frame).padStart(3, '0')}.webp`, BASE);
    url.searchParams.set('v', MEDIA_VERSION);
    return url.href;
  };

  function setChapterInteraction(index, active, allowFocus = active) {
    const original = chapterInteraction[index];
    chapters[index].inert = !active || original.inert;
    // Preserve keyboard behavior on browsers predating native inert support as well.
    original.focusables.forEach(({ node, tabindex, ariaHidden, pointerEvents }) => {
      if (!allowFocus) {
        node.setAttribute('tabindex', '-1');
        node.setAttribute('aria-hidden', 'true');
        node.style.pointerEvents = 'none';
      } else {
        if (tabindex === null) node.removeAttribute('tabindex');
        else node.setAttribute('tabindex', tabindex);
        if (ariaHidden === null) node.removeAttribute('aria-hidden');
        else node.setAttribute('aria-hidden', ariaHidden);
        node.style.pointerEvents = pointerEvents || '';
      }
    });
  }

  function schedule() {
    if (disposed || document.hidden || reduced.matches || raf) return;
    raf = requestAnimationFrame(() => { raf = 0; render(); });
  }

  function trimCache() {
    const limit = width > 760 ? 36 : 20;
    for (const key of cache.keys()) {
      if (cache.size <= limit) break;
      if (!isPoster(key) && key !== keyFor(current.chapter, current.frame)) cache.delete(key);
    }
  }

  function activateIfReady() {
    if (disposed || reduced.matches || readinessFailed || enabled) return;
    if (!CHAPTERS.every((_, index) => cache.has(keyFor(index)))) return;
    enabled = true;
    root.dataset.endingReady = 'false';
    root.style.setProperty('--ending-title-opacity', 0);
    root.style.setProperty('--ending-cta-opacity', 0);
    document.documentElement.classList.add('story-ready');
    root.classList.add('is-enhanced');
    buttons.forEach(button => { button.disabled = false; });
    schedule();
  }

  function pump() {
    if (disposed || document.hidden || reduced.matches || readinessFailed) return;
    while (pending.size < 4 && queue.size) {
      const [key, item] = [...queue].sort((a, b) => a[1].priority - b[1].priority)[0];
      queue.delete(key);
      if (pending.has(key) || cache.has(key) || failed.has(key)) continue;
      pending.add(key);
      const image = new Image();
      image.decoding = 'async';
      image.onload = () => {
        pending.delete(key);
        if (disposed) return;
        cache.set(key, { image, chapter: item.chapter, frame: item.frame });
        trimCache();
        activateIfReady();
        // Recompute the latest scroll position. This image may belong to an old request.
        schedule();
        pump();
      };
      image.onerror = () => {
        pending.delete(key);
        failed.add(key);
        if (disposed) return;
        if (isPoster(key)) {
          readinessFailed = true;
          deactivate();
        } else {
          schedule();
          pump();
        }
      };
      image.src = urlFor(item.chapter, item.frame);
    }
  }

  function request(chapter, frame, priority = 0) {
    const key = keyFor(chapter, frame);
    if (!cache.has(key) && !pending.has(key) && !failed.has(key)) {
      queue.set(key, { chapter, frame, priority });
    }
  }

  function closest(chapter, frame) {
    let best;
    let distance = Infinity;
    for (const [key, item] of cache) {
      if (item.chapter === chapter && Math.abs(item.frame - frame) < distance) {
        best = [key, item];
        distance = Math.abs(item.frame - frame);
      }
    }
    if (!best) return null;
    cache.delete(best[0]);
    cache.set(...best);
    return best[1].image;
  }

  function drawImage(target, image, rect, zoom = 1, positionY = .5) {
    const scale = Math.max(rect.w / image.naturalWidth, rect.h / image.naturalHeight) * zoom;
    const w = image.naturalWidth * scale;
    const h = image.naturalHeight * scale;
    target.drawImage(image, rect.x + (rect.w - w) / 2, rect.y + (rect.h - h) * positionY, w, h);
  }

  function drawScene(target, chapter, local, frame) {
    const image = closest(chapter, frame);
    if (!image) return;
    const mode = CHAPTERS[chapter].fit;
    const compact = !(height <= 480 && width > height) && (width <= 760 || width / height < 1);
    target.fillStyle = '#101310';
    target.fillRect(0, 0, width, height);
    if (mode === 'cotton') {
      drawImage(target, image, { x: 0, y: 0, w: width, h: height }, 1 + clamp(local) * .08, compact ? .5 : .6);
    } else if (mode === 'garment') {
      const pose = endingPose({ width, height, imageWidth: image.naturalWidth, imageHeight: image.naturalHeight, local });
      target.drawImage(image, pose.x, pose.y, pose.w, pose.h);
    } else {
      drawImage(target, image, { x: 0, y: 0, w: width, h: height }, 1.025);
    }
  }

  function render() {
    if (!enabled || disposed || document.hidden || reduced.matches) return;
    const stageBounds = stage.getBoundingClientRect();
    const bounds = root.getBoundingClientRect();
    width = Math.max(1, stageBounds.width);
    height = Math.max(1, stageBounds.height);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const pixelWidth = Math.round(width * dpr);
    const pixelHeight = Math.round(height * dpr);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    const progress = progressFromBounds(bounds.top, bounds.height, height);
    current = storyState(progress);
    const endingLocal = current.chapter === 4 ? current.local : 0;
    const titleOpacity = smooth((endingLocal - .3) / .25);
    const ctaOpacity = smooth((endingLocal - .73) / .15);
    const endingReady = current.chapter === 4 && ctaOpacity === 1;
    root.dataset.endingReady = String(endingReady);
    root.style.setProperty('--ending-title-opacity', titleOpacity);
    root.style.setProperty('--ending-cta-opacity', ctaOpacity);
    root.style.setProperty('--journey-progress', progress);
    root.style.setProperty('--chapter-progress', current.local);
    root.dataset.chapter = current.active;
    root.dataset.frame = current.frame;
    chapters.forEach((chapter, index) => {
      setChapterInteraction(index, index === current.active, index === current.active && (index !== 4 || endingReady));
      chapter.classList.toggle('is-current', index === current.active);
      chapter.setAttribute('aria-hidden', index === current.active ? 'false' : 'true');
    });
    buttons.forEach((button, index) => {
      button.classList.toggle('is-current', index === current.active);
      if (index === current.active) button.setAttribute('aria-current', 'step');
      else button.removeAttribute('aria-current');
    });
    drawScene(context, current.chapter, current.local, current.frame);
    if (current.blend > 0) {
      if (transitionLayer.width !== pixelWidth || transitionLayer.height !== pixelHeight) {
        transitionLayer.width = pixelWidth;
        transitionLayer.height = pixelHeight;
      }
      transitionContext.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawScene(transitionContext, current.chapter + 1, 0, 1);
      context.save();
      context.globalAlpha = current.blend;
      context.drawImage(transitionLayer, 0, 0, width, height);
      context.restore();
    }
    // Drop stale queued frames after a fast jump; at most four in-flight images can finish.
    queue.clear();
    if (bounds.bottom > 0 && bounds.top < innerHeight) {
      const radius = navigator.connection?.saveData ? 1 : 4;
      for (let offset = -radius; offset <= radius; offset++) {
        const frame = clamp(current.frame + offset, 1, CHAPTERS[current.chapter].frames);
        request(current.chapter, frame, Math.abs(offset));
      }
      pump();
    }
  }

  function deactivate() {
    enabled = false;
    queue.clear();
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    document.documentElement.classList.remove('story-ready');
    root.classList.remove('is-enhanced');
    delete root.dataset.endingReady;
    root.style.setProperty('--ending-title-opacity', 1);
    root.style.setProperty('--ending-cta-opacity', 1);
    chapters.forEach((chapter, index) => {
      setChapterInteraction(index, true);
      chapter.classList.remove('is-current');
      chapter.removeAttribute('aria-hidden');
    });
    buttons.forEach((button, index) => {
      button.disabled = originalButtonDisabled[index];
      button.classList.remove('is-current');
      button.removeAttribute('aria-current');
    });
  }

  function start() {
    if (disposed || reduced.matches || readinessFailed) return;
    CHAPTERS.forEach((_, index) => request(index, 1, -1));
    activateIfReady();
    pump();
  }
  const onPreferenceChange = () => reduced.matches ? deactivate() : start();
  const onVisibility = () => {
    if (document.hidden) {
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
    } else { start(); schedule(); }
  };
  const jumpHandlers = buttons.map((button, index) => {
    const jump = () => {
      if (enabled) {
        const bounds = root.getBoundingClientRect();
        const stageHeight = stage.getBoundingClientRect().height;
        window.scrollTo({
          top: scrollY + bounds.top + (bounds.height - stageHeight) * (index + (index === 4 ? .9 : 0)) / CHAPTERS.length,
          behavior: 'smooth',
        });
      } else {
        chapters[index].scrollIntoView({ behavior: 'instant', block: 'start' });
      }
    };
    button.addEventListener('click', jump);
    return jump;
  });
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', schedule, { passive: true });
  document.addEventListener('visibilitychange', onVisibility);
  reduced.addEventListener('change', onPreferenceChange);
  start();

  return () => {
    disposed = true;
    deactivate();
    cache.clear();
    buttons.forEach((button, index) => button.removeEventListener('click', jumpHandlers[index]));
    window.removeEventListener('scroll', schedule);
    window.removeEventListener('resize', schedule);
    document.removeEventListener('visibilitychange', onVisibility);
    reduced.removeEventListener('change', onPreferenceChange);
  };
}
