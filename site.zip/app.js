import { initStores } from './stores.js?v=58ecf39a18de';
import { initScrollStory } from './scroll-story.js?v=833d87cc2e5a';

initScrollStory();
initStores();

const header = document.querySelector('#header');
const journey = document.querySelector('#journey');
new IntersectionObserver(([entry]) => {
  header.classList.toggle('is-light', !entry.isIntersecting);
}).observe(journey);

document.querySelector('#year').textContent = String(new Date().getFullYear());
document.querySelector('#privacy-button').addEventListener('click', () => {
  document.querySelector('#info-dialog').showModal();
});
document.querySelectorAll('dialog').forEach(dialog => {
  dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const box = dialog.getBoundingClientRect();
    if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
  });
});
document.addEventListener('click', event => {
  const close = event.target.closest('[data-close]');
  if (close) close.closest('dialog')?.close();
  if (event.target.closest('a[href="#source-note"]')) document.querySelector('#source-note').open = true;
});

// Keep shared bookmarks useful after removing the film library.
if (['#home', '#collection', '#attitude', '#films'].includes(location.hash)) location.replace('#journey');
